import queue
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
import tkinter as tk
import torch
from PIL import Image, ImageTk
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from models.experimental import attempt_load
from utils.datasets import letterbox
from utils.general import check_img_size, non_max_suppression, scale_coords
from utils.sort import ByteTrackSort
from utils.torch_utils import select_device


IMAGE_EXTS = {".bmp", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".webp"}
VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv"}


@dataclass
class AppConfig:
    weights: str = "best.pt"
    source_type: str = "sequence"
    source_root: str = ""
    img_size: int = 640
    conf_thres: float = 0.25
    iou_thres: float = 0.45
    track_high_thres: float = 0.25
    track_low_thres: float = 0.05
    sort_iou_thres: float = 0.30
    sort_center_dist: float = 0.0
    sort_max_age: int = 15
    sort_min_hits: int = 3
    sort_output_age: int = 0
    display_fps: float = 8.0
    device: str = "0"


def resolve_modal_dir(root: Path, preferred: str) -> Path:
    candidates = [
        root / preferred,
        root / "img1",
    ]
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError(f"Missing directory for {preferred}: {root}")


def resolve_modal_video(root: Path, preferred: str) -> Path:
    exact = root / preferred
    if exact.is_file():
        return exact
    stem = Path(preferred).stem.lower()
    candidates = sorted(
        p for p in root.iterdir()
        if p.is_file() and p.suffix.lower() in VIDEO_EXTS and stem.split("_")[0] in p.stem.lower()
    )
    if candidates:
        return candidates[0]
    raise FileNotFoundError(f"Missing video for {preferred}: {root}")


class TriModalSequenceSource:
    def __init__(self, source_root: str):
        root = Path(source_root).resolve()
        self.ir_dir = resolve_modal_dir(root, "ir_frame")
        self.rgb_dir = resolve_modal_dir(root, "rgb_frame")
        self.event_dir = resolve_modal_dir(root, "event_frame")
        self.ir_frames = [p for p in sorted(self.ir_dir.iterdir()) if p.suffix.lower() in IMAGE_EXTS]
        if not self.ir_frames:
            raise FileNotFoundError(f"No IR frames found in {self.ir_dir}")
        self.index = 0

    def read(self) -> Tuple[bool, Optional[Dict], int]:
        if self.index >= len(self.ir_frames):
            return False, None, self.index
        ir_path = self.ir_frames[self.index]
        rgb_path = self.rgb_dir / ir_path.name
        event_path = self.event_dir / ir_path.name
        if not rgb_path.exists() or not event_path.exists():
            raise FileNotFoundError(f"Missing paired frame for {ir_path.name}")
        payload = {
            "ir": cv2.imread(str(ir_path)),
            "rgb": cv2.imread(str(rgb_path)),
            "event": cv2.imread(str(event_path)),
            "name": ir_path.name,
        }
        if any(frame is None for frame in payload.values() if not isinstance(frame, str)):
            raise FileNotFoundError(f"Failed to load paired frame set for {ir_path.name}")
        self.index += 1
        return True, payload, self.index

    def release(self):
        return None


class TriModalVideoSource:
    def __init__(self, source_root: str):
        root = Path(source_root).resolve()
        self.ir_cap = cv2.VideoCapture(str(resolve_modal_video(root, "ir_video_clip.mp4")))
        self.rgb_cap = cv2.VideoCapture(str(resolve_modal_video(root, "rgb_video_clip.mp4")))
        self.event_cap = cv2.VideoCapture(str(resolve_modal_video(root, "event_video_clip.mp4")))
        if not self.ir_cap.isOpened() or not self.rgb_cap.isOpened() or not self.event_cap.isOpened():
            raise FileNotFoundError(f"Unable to open one or more modality videos under {root}")
        self.index = 0

    def read(self) -> Tuple[bool, Optional[Dict], int]:
        ok_ir, ir = self.ir_cap.read()
        ok_rgb, rgb = self.rgb_cap.read()
        ok_event, event = self.event_cap.read()
        if not (ok_ir and ok_rgb and ok_event):
            return False, None, self.index
        self.index += 1
        return True, {"ir": ir, "rgb": rgb, "event": event, "name": f"frame{self.index:04d}"}, self.index

    def release(self):
        self.ir_cap.release()
        self.rgb_cap.release()
        self.event_cap.release()


class TriModalDetector:
    def __init__(self, config: AppConfig):
        self.device = select_device(config.device)
        self.half = self.device.type != "cpu"
        self.model = attempt_load(config.weights, map_location=self.device)
        self.stride = int(self.model.stride.max())
        self.img_size = check_img_size(config.img_size, s=self.stride)
        if self.half:
            self.model.half()
        self.conf_thres = config.conf_thres
        self.iou_thres = config.iou_thres

    def _preprocess(self, image: np.ndarray) -> torch.Tensor:
        image = letterbox(image, self.img_size, stride=self.stride)[0]
        image = image[:, :, ::-1].transpose(2, 0, 1)
        image = np.ascontiguousarray(image)
        tensor = torch.from_numpy(image).to(self.device)
        tensor = tensor.half() if self.half else tensor.float()
        tensor /= 255.0
        return tensor.unsqueeze(0)

    def detect(self, ir_bgr: np.ndarray, rgb_bgr: np.ndarray, event_bgr: np.ndarray) -> np.ndarray:
        ir_tensor = self._preprocess(ir_bgr)
        rgb_tensor = self._preprocess(rgb_bgr)
        event_tensor = self._preprocess(event_bgr)
        pred = self.model(rgb_tensor, ir_tensor, event_tensor, augment=False)[0]
        pred = non_max_suppression(pred, self.conf_thres, self.iou_thres)
        det = pred[0]
        if len(det) == 0:
            return np.empty((0, 5), dtype=np.float32)
        det[:, :4] = scale_coords(ir_tensor.shape[2:], det[:, :4], ir_bgr.shape).round()
        return det.detach().cpu().numpy()[:, :5].astype(np.float32)


def color_for_id(track_id: int) -> Tuple[int, int, int]:
    return (
        int((37 * track_id) % 255),
        int((17 * track_id) % 255),
        int((29 * track_id) % 255),
    )


def draw_tracks(ir_frame: np.ndarray, tracks: np.ndarray) -> np.ndarray:
    canvas = ir_frame.copy()
    for track in tracks:
        x1, y1, x2, y2, track_id = track
        color = color_for_id(int(track_id))
        cv2.rectangle(canvas, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
        cv2.putText(
            canvas,
            f"ID {int(track_id)}",
            (int(x1), max(18, int(y1) - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            color,
            2,
            cv2.LINE_AA,
        )
    return canvas


class ProcessingWorker(threading.Thread):
    def __init__(self, config: AppConfig, output_queue: "queue.Queue[Dict]"):
        super().__init__(daemon=True)
        self.config = config
        self.output_queue = output_queue
        self.stop_event = threading.Event()

    def stop(self):
        self.stop_event.set()

    def _build_source(self):
        if self.config.source_type == "video":
            return TriModalVideoSource(self.config.source_root)
        return TriModalSequenceSource(self.config.source_root)

    def run(self):
        source = None
        try:
            source = self._build_source()
            detector = TriModalDetector(self.config)
            tracker = ByteTrackSort(
                max_age=self.config.sort_max_age,
                min_hits=self.config.sort_min_hits,
                iou_threshold=self.config.sort_iou_thres,
                low_iou_threshold=max(0.1, self.config.sort_iou_thres - 0.1),
                high_det_thresh=self.config.track_high_thres,
                low_det_thresh=self.config.track_low_thres,
                output_unmatched_age=self.config.sort_output_age,
                center_distance_threshold=self.config.sort_center_dist,
            )
            frame_delay = 1.0 / max(self.config.display_fps, 0.1)

            while not self.stop_event.is_set():
                started = time.time()
                ok, payload, frame_index = source.read()
                if not ok or payload is None:
                    self.output_queue.put({"type": "done"})
                    break

                dets = detector.detect(payload["ir"], payload["rgb"], payload["event"])
                tracks = tracker.update(dets)
                annotated = draw_tracks(payload["ir"], tracks)
                image = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
                self.output_queue.put(
                    {
                        "type": "frame",
                        "image": image,
                        "frame_index": frame_index,
                        "detections": len(dets),
                        "tracks": len(tracks),
                        "source_name": payload["name"],
                    }
                )

                sleep_time = frame_delay - (time.time() - started)
                if sleep_time > 0:
                    time.sleep(sleep_time)
        except Exception as exc:
            self.output_queue.put({"type": "error", "message": str(exc)})
        finally:
            if source is not None:
                source.release()


class PrototypeGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Tri-Modal Anti-UAV Console")
        self.root.geometry("1320x820")
        self.root.configure(bg="#10151c")
        self.config = AppConfig()
        self.worker: Optional[ProcessingWorker] = None
        self.output_queue: "queue.Queue[Dict]" = queue.Queue()
        self.photo = None

        self.source_type_var = tk.StringVar(value=self.config.source_type)
        self.source_root_var = tk.StringVar(value="")
        self.weights_var = tk.StringVar(value=self.config.weights)
        self.status_var = tk.StringVar(value="状态: 空闲")
        self.meta_var = tk.StringVar(value="帧号: - | det: 0 | track: 0")

        self._build_styles()
        self._build_layout()
        self.root.after(40, self._poll_queue)

    def _build_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Panel.TFrame", background="#10151c")
        style.configure("Card.TFrame", background="#16202b")
        style.configure("Toolbar.TFrame", background="#111923")
        style.configure("Title.TLabel", background="#10151c", foreground="#d7e3f4", font=("Segoe UI", 16, "bold"))
        style.configure("Body.TLabel", background="#16202b", foreground="#d7e3f4", font=("Segoe UI", 10))

    def _build_layout(self):
        outer = ttk.Frame(self.root, style="Panel.TFrame", padding=14)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="三模态无人机检测与跟踪系统", style="Title.TLabel").pack(anchor="w", pady=(0, 12))

        toolbar = ttk.Frame(outer, style="Toolbar.TFrame", padding=10)
        toolbar.pack(fill="x", pady=(0, 10))
        ttk.Button(toolbar, text="选择输入目录", command=self._browse_root).pack(side="left")
        ttk.Button(toolbar, text="启动", command=self.start).pack(side="left", padx=8)
        ttk.Button(toolbar, text="停止", command=self.stop).pack(side="left")
        ttk.Button(toolbar, text="设置", command=self.open_settings).pack(side="right")

        content = ttk.Frame(outer, style="Panel.TFrame")
        content.pack(fill="both", expand=True)
        content.columnconfigure(0, weight=3)
        content.columnconfigure(1, weight=2)
        content.rowconfigure(0, weight=1)

        left = ttk.Frame(content, style="Card.TFrame", padding=12)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)

        ttk.Label(left, text="IR 显示窗口", style="Body.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        self.video_label = tk.Label(left, bg="#0a0f14", bd=0)
        self.video_label.grid(row=1, column=0, sticky="nsew")
        ttk.Label(left, textvariable=self.status_var, style="Body.TLabel").grid(row=2, column=0, sticky="w", pady=(10, 2))
        ttk.Label(left, textvariable=self.meta_var, style="Body.TLabel").grid(row=3, column=0, sticky="w")

        right = ttk.Frame(content, style="Card.TFrame", padding=12)
        right.grid(row=0, column=1, sticky="nsew")
        right.rowconfigure(3, weight=1)
        right.columnconfigure(0, weight=1)

        ttk.Label(right, text="系统摘要", style="Body.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        self.summary_var = tk.StringVar()
        self._refresh_summary()
        tk.Label(right, textvariable=self.summary_var, justify="left", anchor="nw", bg="#0c1218", fg="#d7e3f4", padx=12, pady=12).grid(row=1, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(right, text="运行日志", style="Body.TLabel").grid(row=2, column=0, sticky="w", pady=(8, 4))
        self.log_list = tk.Listbox(right, bg="#0c1218", fg="#d7e3f4", borderwidth=0, highlightthickness=0)
        self.log_list.grid(row=3, column=0, sticky="nsew")

    def _browse_root(self):
        path = filedialog.askdirectory(title="选择三模态外层目录")
        if path:
            self.source_root_var.set(path)
            self._refresh_summary()

    def _refresh_summary(self):
        self.summary_var.set(
            f"输入类型: {self.source_type_var.get()}\n"
            f"输入目录: {self.source_root_var.get().strip() or '(未选择)'}\n"
            f"权重文件: {Path(self.weights_var.get()).name}\n"
            f"显示模态: IR\n"
            f"处理模态: RGB + IR + event"
        )

    def open_settings(self):
        win = tk.Toplevel(self.root)
        win.title("系统设置")
        win.geometry("560x360")
        win.configure(bg="#10151c")

        card = ttk.Frame(win, style="Card.TFrame", padding=16)
        card.pack(fill="both", expand=True, padx=14, pady=14)
        card.columnconfigure(1, weight=1)

        ttk.Label(card, text="输入类型", style="Body.TLabel").grid(row=0, column=0, sticky="w", pady=6)
        ttk.Combobox(card, textvariable=self.source_type_var, values=["sequence", "video"], state="readonly").grid(row=0, column=1, sticky="ew", pady=6)
        ttk.Label(card, text="输入目录", style="Body.TLabel").grid(row=1, column=0, sticky="w", pady=6)
        ttk.Entry(card, textvariable=self.source_root_var).grid(row=1, column=1, sticky="ew", pady=6)
        ttk.Button(card, text="浏览", command=self._browse_root).grid(row=1, column=2, padx=(8, 0), pady=6)
        ttk.Label(card, text="权重路径", style="Body.TLabel").grid(row=2, column=0, sticky="w", pady=6)
        ttk.Entry(card, textvariable=self.weights_var).grid(row=2, column=1, columnspan=2, sticky="ew", pady=6)

        footer = ttk.Frame(card, style="Card.TFrame")
        footer.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(16, 0))
        ttk.Button(footer, text="应用", command=lambda: (self._refresh_summary(), win.destroy())).pack(side="right")

    def _build_config(self) -> AppConfig:
        return AppConfig(
            weights=self.weights_var.get().strip() or "best.pt",
            source_type=self.source_type_var.get(),
            source_root=self.source_root_var.get().strip(),
            conf_thres=self.config.conf_thres,
            iou_thres=self.config.iou_thres,
            track_high_thres=self.config.track_high_thres,
            track_low_thres=self.config.track_low_thres,
            sort_iou_thres=self.config.sort_iou_thres,
            sort_center_dist=self.config.sort_center_dist,
            sort_max_age=self.config.sort_max_age,
            sort_min_hits=self.config.sort_min_hits,
            sort_output_age=self.config.sort_output_age,
            display_fps=self.config.display_fps,
            device=self.config.device,
        )

    def start(self):
        if self.worker and self.worker.is_alive():
            return
        config = self._build_config()
        if not config.source_root:
            messagebox.showerror("配置错误", "请选择三模态输入目录。")
            return
        self.config = config
        self._refresh_summary()
        self.status_var.set("状态: 运行中")
        self.log_list.insert(0, f"[INFO] start {config.source_type} source={config.source_root}")
        self.worker = ProcessingWorker(config, self.output_queue)
        self.worker.start()

    def stop(self):
        if self.worker:
            self.worker.stop()
        self.status_var.set("状态: 已停止")
        self.log_list.insert(0, "[INFO] processing stopped")

    def _poll_queue(self):
        try:
            while True:
                item = self.output_queue.get_nowait()
                if item["type"] == "frame":
                    self._update_frame(item["image"])
                    self.meta_var.set(
                        f"帧号: {item['frame_index']} | det: {item['detections']} | track: {item['tracks']}"
                    )
                    self.log_list.insert(0, f"[FRAME] {item['source_name']} det={item['detections']} track={item['tracks']}")
                elif item["type"] == "done":
                    self.status_var.set("状态: 处理完成")
                    self.log_list.insert(0, "[INFO] input stream complete")
                elif item["type"] == "error":
                    self.status_var.set("状态: 出错")
                    messagebox.showerror("运行错误", item["message"])
        except queue.Empty:
            pass
        self.root.after(40, self._poll_queue)

    def _update_frame(self, rgb_image: np.ndarray):
        h, w = rgb_image.shape[:2]
        scale = min(1.0, 620 / max(h, 1), 900 / max(w, 1))
        resized = cv2.resize(rgb_image, (int(w * scale), int(h * scale)))
        image = Image.fromarray(resized)
        self.photo = ImageTk.PhotoImage(image=image)
        self.video_label.configure(image=self.photo)


def main():
    root = tk.Tk()
    app = PrototypeGUI(root)
    root.protocol("WM_DELETE_WINDOW", lambda: (app.stop(), root.destroy()))
    root.mainloop()


if __name__ == "__main__":
    main()
