import argparse
import configparser
import time
from pathlib import Path

import cv2
import numpy as np
import torch

from models.experimental import attempt_load
from utils.datasets import letterbox
from utils.general import check_img_size, increment_path, non_max_suppression, scale_coords, set_logging
from utils.sort import ByteTrackSort, Sort
from utils.torch_utils import select_device, time_synchronized


IMG_EXTS = {".bmp", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".webp"}


def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=str, default="best.pt", help="model weight path")
    parser.add_argument("--source-ir", type=str, default="images/testdata", help="IR MOT root / seq root / img dir")
    parser.add_argument("--source-rgb", type=str, required=True, help="RGB MOT root with matching seq layout")
    parser.add_argument("--source-event", type=str, required=True, help="event MOT root with matching seq layout")
    parser.add_argument("--img-size", type=int, default=640, help="inference size")
    parser.add_argument("--conf-thres", type=float, default=0.25, help="confidence threshold")
    parser.add_argument("--iou-thres", type=float, default=0.45, help="NMS IoU threshold")
    parser.add_argument("--device", default="0", help="cuda device or cpu")
    parser.add_argument("--augment", action="store_true", help="augmented inference")
    parser.add_argument("--classes", nargs="+", type=int, help="filter classes")
    parser.add_argument("--agnostic-nms", action="store_true", help="class agnostic NMS")
    parser.add_argument("--project", default="runs/track", help="save root")
    parser.add_argument("--name", default="sort_ir", help="save experiment name")
    parser.add_argument("--exist-ok", action="store_true", help="reuse existing exp dir")
    parser.add_argument("--line-thickness", type=int, default=2, help="box thickness")
    parser.add_argument("--save-video", action="store_true", help="save per-sequence video")
    parser.add_argument("--save-frames", action="store_true", help="save annotated jpg frames")
    parser.add_argument("--save-det", action="store_true", help="save raw detections in MOT txt")
    parser.add_argument("--sort-max-age", type=int, default=15, help="SORT max age")
    parser.add_argument("--sort-min-hits", type=int, default=3, help="SORT min hits")
    parser.add_argument("--sort-iou-thres", type=float, default=0.3, help="SORT association IoU")
    parser.add_argument(
        "--sort-center-dist",
        type=float,
        default=0.0,
        help="optional center-distance association threshold in pixels for fast tiny targets",
    )
    parser.add_argument(
        "--tracker",
        type=str,
        default="sort",
        choices=["sort", "bytetrack", "bytetrackv2"],
        help="tracker backend",
    )
    parser.add_argument("--max-frames", type=int, default=0, help="debug only: stop each sequence after N frames")
    parser.add_argument(
        "--sort-output-age",
        type=int,
        default=0,
        help="also emit predicted tracks for up to this many unmatched frames to bridge short detector flicker",
    )
    parser.add_argument(
        "--track-high-thres",
        type=float,
        default=None,
        help="high-confidence threshold for ByteTrack first-stage association; defaults to --conf-thres",
    )
    parser.add_argument(
        "--track-low-thres",
        type=float,
        default=0.05,
        help="low-confidence threshold for ByteTrack second-stage association",
    )
    parser.add_argument(
        "--track-low-iou-thres",
        type=float,
        default=None,
        help="IoU threshold for ByteTrack low-score association; defaults to --sort-iou-thres",
    )
    parser.add_argument("--min-box-area", type=float, default=0.0, help="drop detections smaller than this area")
    parser.add_argument("--max-box-area", type=float, default=0.0, help="drop detections larger than this area")
    parser.add_argument("--max-box-width", type=float, default=0.0, help="drop detections wider than this")
    parser.add_argument("--max-box-height", type=float, default=0.0, help="drop detections taller than this")
    parser.add_argument("--topk-conf", type=int, default=0, help="keep top-k detections by confidence after filtering")
    parser.add_argument("--topk-smallest", type=int, default=0, help="keep top-k detections with smallest area after filtering")
    parser.add_argument(
        "--box-scale",
        type=float,
        default=1.0,
        help="scale predicted boxes around their center before filtering/tracking (e.g. 0.8 shrinks boxes)",
    )
    parser.add_argument("--box-scale-x", type=float, default=1.0, help="extra horizontal box scale around center")
    parser.add_argument("--box-scale-y", type=float, default=1.0, help="extra vertical box scale around center")
    parser.add_argument("--box-shift-x", type=float, default=0.0, help="global x shift applied after box scaling")
    parser.add_argument("--box-shift-y", type=float, default=0.0, help="global y shift applied after box scaling")
    parser.add_argument("--seq-file", type=str, default="", help="optional text file with one sequence name per line")
    parser.add_argument("--seq-min-id", type=int, default=None, help="keep sequences whose numeric id is >= this value")
    parser.add_argument("--seq-max-id", type=int, default=None, help="keep sequences whose numeric id is <= this value")
    parser.add_argument("--seq-names", nargs="+", default=None, help="optional explicit sequence names to keep")
    return parser.parse_args()


def collect_sequences(source):
    source_path = Path(source).resolve()
    if not source_path.exists():
        raise FileNotFoundError(f"Source not found: {source_path}")

    if source_path.name == "img1":
        return [{"name": source_path.parent.name, "img_dir": source_path, "seq_dir": source_path.parent}]

    if (source_path / "img1").is_dir():
        return [{"name": source_path.name, "img_dir": source_path / "img1", "seq_dir": source_path}]

    seqs = []
    for seq_dir in sorted(source_path.iterdir()):
        img_dir = seq_dir / "img1"
        if seq_dir.is_dir() and img_dir.is_dir():
            seqs.append({"name": seq_dir.name, "img_dir": img_dir, "seq_dir": seq_dir})

    if not seqs:
        raise FileNotFoundError(f"No MOT sequence found under {source_path}")
    return seqs


def sequence_numeric_id(seq_name):
    try:
        return int(seq_name)
    except ValueError:
        return None


def load_sequence_names(seq_file):
    if not seq_file:
        return None
    path = Path(seq_file).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Sequence file not found: {path}")
    names = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not names:
        raise ValueError(f"No sequence names found in {path}")
    return set(names)


def filter_sequences(sequences, opt):
    selected_names = load_sequence_names(opt.seq_file) if opt.seq_file else (set(opt.seq_names) if opt.seq_names else None)
    filtered = []
    for seq in sequences:
        seq_name = seq["name"]
        if selected_names is not None and seq_name not in selected_names:
            continue

        seq_id = sequence_numeric_id(seq_name)
        if opt.seq_min_id is not None and seq_id is not None and seq_id < opt.seq_min_id:
            continue
        if opt.seq_max_id is not None and seq_id is not None and seq_id > opt.seq_max_id:
            continue
        filtered.append(seq)

    if not filtered:
        raise ValueError("No sequence left after applying sequence filters.")
    return filtered


def collect_frame_paths(img_dir):
    frames = [p for p in sorted(img_dir.iterdir()) if p.suffix.lower() in IMG_EXTS]
    if not frames:
        raise FileNotFoundError(f"No image frames found in {img_dir}")
    return frames


def get_corresponding_frame(frame_path, source_root):
    source_root = Path(source_root).resolve()
    seq_name = frame_path.parent.parent.name
    candidates = [
        source_root / seq_name / "img1" / frame_path.name,
        source_root / seq_name / frame_path.name,
        source_root / frame_path.name,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"Matching frame not found for {frame_path.name} under {source_root}")


def load_image(path):
    img = cv2.imread(str(path))
    if img is None:
        raise FileNotFoundError(f"Failed to read image: {path}")
    return img


def preprocess_image(img_bgr, img_size, stride):
    img = letterbox(img_bgr, img_size, stride=stride)[0]
    img = img[:, :, ::-1].transpose(2, 0, 1)
    return np.ascontiguousarray(img)


def image_to_tensor(img_np, device, half):
    tensor = torch.from_numpy(img_np).to(device)
    tensor = tensor.half() if half else tensor.float()
    tensor /= 255.0
    if tensor.ndimension() == 3:
        tensor = tensor.unsqueeze(0)
    return tensor


def filter_detections(det_np, opt):
    if det_np.size == 0:
        return det_np

    widths = det_np[:, 2] - det_np[:, 0]
    heights = det_np[:, 3] - det_np[:, 1]
    areas = widths * heights
    keep = np.ones(len(det_np), dtype=bool)

    if opt.min_box_area > 0:
        keep &= areas >= opt.min_box_area
    if opt.max_box_area > 0:
        keep &= areas <= opt.max_box_area
    if opt.max_box_width > 0:
        keep &= widths <= opt.max_box_width
    if opt.max_box_height > 0:
        keep &= heights <= opt.max_box_height
    det_np = det_np[keep]
    if det_np.size == 0:
        return det_np

    widths = det_np[:, 2] - det_np[:, 0]
    heights = det_np[:, 3] - det_np[:, 1]
    areas = widths * heights

    if opt.topk_smallest > 0 and len(det_np) > opt.topk_smallest:
        order = np.argsort(areas)[:opt.topk_smallest]
        det_np = det_np[order]
        areas = areas[order]

    if opt.topk_conf > 0 and len(det_np) > opt.topk_conf:
        order = np.argsort(-det_np[:, 4])[:opt.topk_conf]
        det_np = det_np[order]
    return det_np


def scale_detection_boxes(det_np, scale, image_shape, scale_x=1.0, scale_y=1.0, shift_x=0.0, shift_y=0.0):
    if (
        det_np.size == 0
        or (
            abs(scale - 1.0) < 1e-6
            and abs(scale_x - 1.0) < 1e-6
            and abs(scale_y - 1.0) < 1e-6
            and abs(shift_x) < 1e-6
            and abs(shift_y) < 1e-6
        )
    ):
        return det_np

    h, w = image_shape[:2]
    boxes = det_np[:, :4]
    cx = (boxes[:, 0] + boxes[:, 2]) * 0.5
    cy = (boxes[:, 1] + boxes[:, 3]) * 0.5
    half_w = (boxes[:, 2] - boxes[:, 0]) * 0.5 * scale * scale_x
    half_h = (boxes[:, 3] - boxes[:, 1]) * 0.5 * scale * scale_y
    cx = cx + shift_x
    cy = cy + shift_y

    boxes[:, 0] = np.clip(cx - half_w, 0, max(w - 1, 0))
    boxes[:, 2] = np.clip(cx + half_w, 0, max(w - 1, 0))
    boxes[:, 1] = np.clip(cy - half_h, 0, max(h - 1, 0))
    boxes[:, 3] = np.clip(cy + half_h, 0, max(h - 1, 0))
    det_np[:, :4] = boxes
    return det_np


def color_for_id(track_id):
    return (
        int((37 * track_id) % 255),
        int((17 * track_id) % 255),
        int((29 * track_id) % 255),
    )


def parse_seq_fps(seq_dir, default_fps=25):
    seqinfo_path = seq_dir / "seqinfo.ini"
    if not seqinfo_path.exists():
        return default_fps

    cfg = configparser.ConfigParser()
    cfg.read(seqinfo_path, encoding="utf-8")
    try:
        return cfg.getint("Sequence", "frameRate")
    except (ValueError, configparser.Error):
        return default_fps


def save_mot_line(file_obj, frame_id, track_id, bbox_xyxy, score=1.0):
    x1, y1, x2, y2 = bbox_xyxy
    w = max(0.0, x2 - x1)
    h = max(0.0, y2 - y1)
    file_obj.write(
        f"{frame_id},{track_id},{x1:.2f},{y1:.2f},{w:.2f},{h:.2f},{score:.4f},-1,-1,-1\n"
    )


def run(opt):
    set_logging()
    device = select_device(opt.device)
    half = device.type != "cpu"

    model = attempt_load(opt.weights, map_location=device)
    stride = int(model.stride.max())
    img_size = check_img_size(opt.img_size, s=stride)
    if half:
        model.half()

    save_dir = increment_path(Path(opt.project) / opt.name, exist_ok=opt.exist_ok)
    save_dir.mkdir(parents=True, exist_ok=True)
    (save_dir / "mot").mkdir(exist_ok=True)
    if opt.save_det:
        (save_dir / "detections").mkdir(exist_ok=True)
    if opt.save_video:
        (save_dir / "videos").mkdir(exist_ok=True)
    if opt.save_frames:
        (save_dir / "frames").mkdir(exist_ok=True)

    sequences = filter_sequences(collect_sequences(opt.source_ir), opt)
    total_frames = 0
    total_infer_time = 0.0
    track_high_thres = opt.conf_thres if opt.track_high_thres is None else opt.track_high_thres
    nms_conf_thres = opt.conf_thres
    if opt.tracker in ("bytetrack", "bytetrackv2"):
        nms_conf_thres = min(track_high_thres, opt.track_low_thres)

    for seq in sequences:
        seq_name = seq["name"]
        frame_paths = collect_frame_paths(seq["img_dir"])
        if opt.tracker in ("bytetrack", "bytetrackv2"):
            low_iou_threshold = opt.track_low_iou_thres
            if opt.tracker == "bytetrackv2" and low_iou_threshold is None:
                low_iou_threshold = max(0.1, opt.sort_iou_thres - 0.1)
            tracker = ByteTrackSort(
                max_age=opt.sort_max_age,
                min_hits=opt.sort_min_hits,
                iou_threshold=opt.sort_iou_thres,
                low_iou_threshold=low_iou_threshold,
                high_det_thresh=track_high_thres,
                low_det_thresh=opt.track_low_thres,
                output_unmatched_age=opt.sort_output_age,
                center_distance_threshold=opt.sort_center_dist,
            )
        else:
            tracker = Sort(
                max_age=opt.sort_max_age,
                min_hits=opt.sort_min_hits,
                iou_threshold=opt.sort_iou_thres,
                output_unmatched_age=opt.sort_output_age,
                center_distance_threshold=opt.sort_center_dist,
            )

        mot_path = save_dir / "mot" / f"{seq_name}.txt"
        det_path = save_dir / "detections" / f"{seq_name}.txt" if opt.save_det else None
        frames_dir = save_dir / "frames" / seq_name if opt.save_frames else None
        if frames_dir:
            frames_dir.mkdir(parents=True, exist_ok=True)

        writer = None
        if opt.save_video:
            sample = load_image(frame_paths[0])
            video_path = save_dir / "videos" / f"{seq_name}.mp4"
            fps = parse_seq_fps(seq["seq_dir"])
            writer = cv2.VideoWriter(
                str(video_path),
                cv2.VideoWriter_fourcc(*"mp4v"),
                fps,
                (sample.shape[1], sample.shape[0]),
            )

        with open(mot_path, "w", encoding="utf-8") as mot_file:
            det_file = open(det_path, "w", encoding="utf-8") if det_path else None
            try:
                for frame_idx, ir_frame_path in enumerate(frame_paths, start=1):
                    if opt.max_frames > 0 and frame_idx > opt.max_frames:
                        break
                    ir_bgr = load_image(ir_frame_path)
                    rgb_frame_path = get_corresponding_frame(ir_frame_path, opt.source_rgb)
                    event_frame_path = get_corresponding_frame(ir_frame_path, opt.source_event)

                    rgb_bgr = load_image(rgb_frame_path)
                    event_bgr = load_image(event_frame_path)

                    ir_np = preprocess_image(ir_bgr, img_size, stride)
                    rgb_np = preprocess_image(rgb_bgr, img_size, stride)
                    event_np = preprocess_image(event_bgr, img_size, stride)

                    ir_tensor = image_to_tensor(ir_np, device, half)
                    rgb_tensor = image_to_tensor(rgb_np, device, half)
                    event_tensor = image_to_tensor(event_np, device, half)

                    t1 = time_synchronized()
                    pred = model(rgb_tensor, ir_tensor, event_tensor, augment=opt.augment)[0]
                    pred = non_max_suppression(
                        pred,
                        nms_conf_thres,
                        opt.iou_thres,
                        classes=opt.classes,
                        agnostic=opt.agnostic_nms,
                    )
                    t2 = time_synchronized()

                    total_frames += 1
                    total_infer_time += (t2 - t1)

                    annotated = ir_bgr.copy()
                    det = pred[0]
                    dets_for_sort = np.empty((0, 5), dtype=np.float32)

                    if len(det):
                        det[:, :4] = scale_coords(ir_tensor.shape[2:], det[:, :4], ir_bgr.shape).round()
                        det_np = det.detach().cpu().numpy()
                        det_np = scale_detection_boxes(
                            det_np,
                            opt.box_scale,
                            ir_bgr.shape,
                            scale_x=opt.box_scale_x,
                            scale_y=opt.box_scale_y,
                            shift_x=opt.box_shift_x,
                            shift_y=opt.box_shift_y,
                        )
                        det_np = filter_detections(det_np, opt)
                        dets_for_sort = det_np[:, :5].astype(np.float32)

                        if det_file is not None:
                            for row in det_np:
                                save_mot_line(det_file, frame_idx, -1, row[:4], row[4])

                    tracks = tracker.update(dets_for_sort)
                    for track in tracks:
                        x1, y1, x2, y2, track_id = track
                        color = color_for_id(int(track_id))
                        cv2.rectangle(
                            annotated,
                            (int(x1), int(y1)),
                            (int(x2), int(y2)),
                            color,
                            opt.line_thickness,
                        )
                        cv2.putText(
                            annotated,
                            f"ID {int(track_id)}",
                            (int(x1), max(int(y1) - 6, 0)),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6,
                            color,
                            2,
                            cv2.LINE_AA,
                        )
                        save_mot_line(mot_file, frame_idx, int(track_id), track[:4], 1.0)

                    if writer is not None:
                        writer.write(annotated)
                    if frames_dir is not None:
                        cv2.imwrite(str(frames_dir / ir_frame_path.name), annotated)

                    print(
                        f"{seq_name} frame {frame_idx:04d}/{len(frame_paths):04d} "
                        f"det={len(dets_for_sort)} track={len(tracks)} "
                        f"infer={(t2 - t1):.4f}s"
                    )
            finally:
                if det_file is not None:
                    det_file.close()
                if writer is not None:
                    writer.release()

    elapsed = total_infer_time / max(total_frames, 1)
    print(f"Tracking finished. sequences={len(sequences)} frames={total_frames} avg_infer={elapsed:.4f}s")
    print(f"Results saved to {save_dir}")


if __name__ == "__main__":
    with torch.no_grad():
        run(parse_opt())
