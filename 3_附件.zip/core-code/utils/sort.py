import numpy as np
from filterpy.kalman import KalmanFilter
from scipy.optimize import linear_sum_assignment


def iou_batch(bb_test, bb_gt):
    bb_gt = np.expand_dims(bb_gt, 0)
    bb_test = np.expand_dims(bb_test, 1)

    xx1 = np.maximum(bb_test[..., 0], bb_gt[..., 0])
    yy1 = np.maximum(bb_test[..., 1], bb_gt[..., 1])
    xx2 = np.minimum(bb_test[..., 2], bb_gt[..., 2])
    yy2 = np.minimum(bb_test[..., 3], bb_gt[..., 3])
    w = np.maximum(0.0, xx2 - xx1)
    h = np.maximum(0.0, yy2 - yy1)
    wh = w * h

    denom = (
        (bb_test[..., 2] - bb_test[..., 0]) * (bb_test[..., 3] - bb_test[..., 1])
        + (bb_gt[..., 2] - bb_gt[..., 0]) * (bb_gt[..., 3] - bb_gt[..., 1])
        - wh
    )
    return wh / np.maximum(denom, 1e-6)


def center_distance_batch(bb_test, bb_gt):
    if len(bb_test) == 0 or len(bb_gt) == 0:
        return np.zeros((len(bb_test), len(bb_gt)), dtype=np.float32)
    test_cx = (bb_test[:, 0] + bb_test[:, 2]) * 0.5
    test_cy = (bb_test[:, 1] + bb_test[:, 3]) * 0.5
    gt_cx = (bb_gt[:, 0] + bb_gt[:, 2]) * 0.5
    gt_cy = (bb_gt[:, 1] + bb_gt[:, 3]) * 0.5
    dx = test_cx[:, None] - gt_cx[None, :]
    dy = test_cy[:, None] - gt_cy[None, :]
    return np.sqrt(dx * dx + dy * dy)


def convert_bbox_to_z(bbox):
    w = bbox[2] - bbox[0]
    h = bbox[3] - bbox[1]
    x = bbox[0] + w / 2.0
    y = bbox[1] + h / 2.0
    s = w * h
    r = w / np.maximum(h, 1e-6)
    return np.array([x, y, s, r], dtype=np.float32).reshape((4, 1))


def convert_x_to_bbox(x, score=None):
    w = np.sqrt(np.maximum(x[2] * x[3], 0.0))
    h = np.maximum(x[2] / np.maximum(w, 1e-6), 0.0)
    bbox = np.array(
        [x[0] - w / 2.0, x[1] - h / 2.0, x[0] + w / 2.0, x[1] + h / 2.0],
        dtype=np.float32,
    ).reshape((1, 4))
    if score is None:
        return bbox
    return np.concatenate((bbox, np.array([[score]], dtype=np.float32)), axis=1)


class KalmanBoxTracker:
    count = 0

    def __init__(self, bbox):
        self.kf = KalmanFilter(dim_x=7, dim_z=4)
        self.kf.F = np.array(
            [
                [1, 0, 0, 0, 1, 0, 0],
                [0, 1, 0, 0, 0, 1, 0],
                [0, 0, 1, 0, 0, 0, 1],
                [0, 0, 0, 1, 0, 0, 0],
                [0, 0, 0, 0, 1, 0, 0],
                [0, 0, 0, 0, 0, 1, 0],
                [0, 0, 0, 0, 0, 0, 1],
            ],
            dtype=np.float32,
        )
        self.kf.H = np.array(
            [
                [1, 0, 0, 0, 0, 0, 0],
                [0, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 0, 0, 0, 0],
                [0, 0, 0, 1, 0, 0, 0],
            ],
            dtype=np.float32,
        )

        self.kf.R[2:, 2:] *= 10.0
        self.kf.P[4:, 4:] *= 1000.0
        self.kf.P *= 10.0
        self.kf.Q[-1, -1] *= 0.01
        self.kf.Q[4:, 4:] *= 0.01
        self.kf.x[:4] = convert_bbox_to_z(bbox)

        self.time_since_update = 0
        self.id = KalmanBoxTracker.count
        KalmanBoxTracker.count += 1
        self.history = []
        self.hits = 1
        self.hit_streak = 1
        self.age = 0
        self.last_observation = np.asarray(bbox[:4], dtype=np.float32)

    def update(self, bbox):
        self.time_since_update = 0
        self.history = []
        self.hits += 1
        self.hit_streak += 1
        self.last_observation = np.asarray(bbox[:4], dtype=np.float32)
        self.kf.update(convert_bbox_to_z(bbox))

    def predict(self):
        if (self.kf.x[6] + self.kf.x[2]) <= 0:
            self.kf.x[6] = 0.0
        self.kf.predict()
        self.age += 1
        if self.time_since_update > 0:
            self.hit_streak = 0
        self.time_since_update += 1
        self.history.append(convert_x_to_bbox(self.kf.x))
        return self.history[-1]

    def get_state(self):
        return convert_x_to_bbox(self.kf.x)

    def get_output_state(self):
        if self.time_since_update == 0:
            return self.last_observation.reshape((1, 4))
        return self.get_state()


def associate_detections_to_trackers(detections, trackers, iou_threshold=0.3, center_distance_threshold=0.0):
    if len(trackers) == 0:
        return (
            np.empty((0, 2), dtype=int),
            np.arange(len(detections), dtype=int),
            np.empty((0,), dtype=int),
        )

    iou_matrix = iou_batch(detections, trackers)
    if center_distance_threshold > 0:
        dist_matrix = center_distance_batch(detections, trackers)
        center_score = 1.0 - np.minimum(dist_matrix, center_distance_threshold) / center_distance_threshold
        score_matrix = np.maximum(iou_matrix, center_score)
    else:
        dist_matrix = None
        score_matrix = iou_matrix

    if min(score_matrix.shape) > 0:
        matched_indices = np.stack(linear_sum_assignment(-score_matrix), axis=1)
    else:
        matched_indices = np.empty((0, 2), dtype=int)

    unmatched_detections = []
    for d in range(len(detections)):
        if d not in matched_indices[:, 0]:
            unmatched_detections.append(d)

    unmatched_trackers = []
    for t in range(len(trackers)):
        if t not in matched_indices[:, 1]:
            unmatched_trackers.append(t)

    matches = []
    for m in matched_indices:
        center_match = (
            center_distance_threshold > 0
            and dist_matrix is not None
            and dist_matrix[m[0], m[1]] <= center_distance_threshold
        )
        if iou_matrix[m[0], m[1]] < iou_threshold and not center_match:
            unmatched_detections.append(m[0])
            unmatched_trackers.append(m[1])
        else:
            matches.append(m.reshape(1, 2))

    if len(matches) == 0:
        matches = np.empty((0, 2), dtype=int)
    else:
        matches = np.concatenate(matches, axis=0)

    return matches, np.array(unmatched_detections), np.array(unmatched_trackers)


class Sort:
    def __init__(self, max_age=15, min_hits=3, iou_threshold=0.3, output_unmatched_age=0, center_distance_threshold=0.0):
        self.max_age = max_age
        self.min_hits = min_hits
        self.iou_threshold = iou_threshold
        self.output_unmatched_age = output_unmatched_age
        self.center_distance_threshold = center_distance_threshold
        self.trackers = []
        self.frame_count = 0

    def update(self, dets=np.empty((0, 5), dtype=np.float32)):
        self.frame_count += 1

        trks = np.zeros((len(self.trackers), 5), dtype=np.float32)
        to_del = []
        ret = []
        for t, _ in enumerate(trks):
            pos = self.trackers[t].predict()[0]
            trks[t] = [pos[0], pos[1], pos[2], pos[3], 0.0]
            if np.any(np.isnan(pos)):
                to_del.append(t)

        trks = np.ma.compress_rows(np.ma.masked_invalid(trks))
        for t in reversed(to_del):
            self.trackers.pop(t)

        matched, unmatched_dets, unmatched_trks = associate_detections_to_trackers(
            dets[:, :4], trks[:, :4], self.iou_threshold, self.center_distance_threshold
        )

        for m in matched:
            self.trackers[m[1]].update(dets[m[0], :4])

        for i in unmatched_dets:
            self.trackers.append(KalmanBoxTracker(dets[i, :4]))

        tracker_index = len(self.trackers)
        for trk in reversed(self.trackers):
            tracker_index -= 1
            d = trk.get_output_state()[0]
            if trk.time_since_update <= self.output_unmatched_age and (
                trk.hit_streak >= self.min_hits or self.frame_count <= self.min_hits
            ):
                ret.append(np.concatenate((d, [trk.id + 1])).reshape(1, 5))
            if trk.time_since_update > self.max_age:
                self.trackers.pop(tracker_index)

        if len(ret) > 0:
            return np.concatenate(ret, axis=0)
        return np.empty((0, 5), dtype=np.float32)


class ByteTrackSort:
    def __init__(
        self,
        max_age=15,
        min_hits=3,
        iou_threshold=0.3,
        low_iou_threshold=None,
        high_det_thresh=0.25,
        low_det_thresh=0.1,
        output_unmatched_age=0,
        center_distance_threshold=0.0,
    ):
        self.max_age = max_age
        self.min_hits = min_hits
        self.iou_threshold = iou_threshold
        self.low_iou_threshold = iou_threshold if low_iou_threshold is None else low_iou_threshold
        self.high_det_thresh = high_det_thresh
        self.low_det_thresh = low_det_thresh
        self.output_unmatched_age = output_unmatched_age
        self.center_distance_threshold = center_distance_threshold
        self.trackers = []
        self.frame_count = 0

    def _predict_trackers(self):
        trks = np.zeros((len(self.trackers), 5), dtype=np.float32)
        to_del = []
        for t, _ in enumerate(trks):
            pos = self.trackers[t].predict()[0]
            trks[t] = [pos[0], pos[1], pos[2], pos[3], 0.0]
            if np.any(np.isnan(pos)):
                to_del.append(t)

        trks = np.ma.compress_rows(np.ma.masked_invalid(trks))
        for t in reversed(to_del):
            self.trackers.pop(t)
        return trks

    def _collect_outputs(self):
        ret = []
        tracker_index = len(self.trackers)
        for trk in reversed(self.trackers):
            tracker_index -= 1
            d = trk.get_output_state()[0]
            if trk.time_since_update <= self.output_unmatched_age and (
                trk.hit_streak >= self.min_hits or self.frame_count <= self.min_hits
            ):
                ret.append(np.concatenate((d, [trk.id + 1])).reshape(1, 5))
            if trk.time_since_update > self.max_age:
                self.trackers.pop(tracker_index)

        if len(ret) > 0:
            return np.concatenate(ret, axis=0)
        return np.empty((0, 5), dtype=np.float32)

    def update(self, dets=np.empty((0, 5), dtype=np.float32)):
        self.frame_count += 1
        trks = self._predict_trackers()

        if len(dets) == 0:
            return self._collect_outputs()

        scores = dets[:, 4]
        high_mask = scores >= self.high_det_thresh
        low_mask = (scores >= self.low_det_thresh) & ~high_mask
        high_dets = dets[high_mask]
        low_dets = dets[low_mask]

        matched_high, unmatched_high, unmatched_trks = associate_detections_to_trackers(
            high_dets[:, :4], trks[:, :4], self.iou_threshold, self.center_distance_threshold
        )

        for m in matched_high:
            self.trackers[m[1]].update(high_dets[m[0], :4])

        unmatched_tracker_indices = unmatched_trks.astype(int)
        if len(low_dets) > 0 and len(unmatched_tracker_indices) > 0:
            low_track_boxes = trks[unmatched_tracker_indices, :4]
            matched_low, unmatched_low, remaining_low_trks = associate_detections_to_trackers(
                low_dets[:, :4], low_track_boxes, self.low_iou_threshold, self.center_distance_threshold
            )
            for m in matched_low:
                tracker_idx = unmatched_tracker_indices[m[1]]
                self.trackers[tracker_idx].update(low_dets[m[0], :4])
            unmatched_tracker_indices = unmatched_tracker_indices[remaining_low_trks.astype(int)]
        else:
            unmatched_low = np.arange(len(low_dets), dtype=int)

        for i in unmatched_high.astype(int):
            self.trackers.append(KalmanBoxTracker(high_dets[i, :4]))

        return self._collect_outputs()
